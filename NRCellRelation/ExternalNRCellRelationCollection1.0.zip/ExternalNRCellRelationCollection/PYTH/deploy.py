import json
import os
import subprocess

if __name__ == '__main__':
    tool_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    config_path = os.path.join(tool_path, "config")
    config_file = os.path.join(config_path, "config.json")
    dictObj = {'moshell_path': os.path.dirname(subprocess.check_output('which mobatch', shell=True).strip())}
    jsObj = json.dumps(dictObj, indent=4)
    print jsObj
    with open(config_file, "w") as f:
        f.write(jsObj)

