#!python2
# coding=utf-8
import codecs
import csv
import os
import sys

default_encoding = "utf-8"
if sys.getdefaultencoding() != default_encoding:
    reload(sys)
    sys.setdefaultencoding(default_encoding)


def write_data_to_csv(data, path="", delimiter=','):
    """

    :param delimiter:str
    :param data:list
    :param path:str
    :return:path
    """
    with open(path, "w") as csvfile:
        if data:
            # csv format
            csvfile.write(codecs.BOM_UTF8)
            writer = csv.writer(csvfile, delimiter=delimiter)
            writer.writerows(data)
    return path


def append_data_to_csv(data, path=""):
    """

    :param data:list
    :param path:str
    :return:
    """
    if data:
        with open(os.path.join(path), "a+") as csvfile:
            # csv format
            csvfile.write(codecs.BOM_UTF8)
            writer = csv.writer(csvfile)
            writer.writerows(data)
    return path


def read_csv_to_data(path=""):
    """

    :param path:str
    :return:data
    """
    data = []
    if path:
        if os.path.exists(path):
            with open(os.path.join(path), "r") as csvfile:
                # csv format
                reader = csv.reader(csvfile)
                for row in reader:
                    # [i.decode("") for i in row]
                    data.append(row)
    return data


def get_dict_key(data, key_cols=None):
    """
    get the key, if key_cols is None return data[0]
    :param data:
    :param key_cols:
    :return:
    """
    key = ""
    if not key_cols:
        key = data[0]                      # default key_cols is 0
    else:
        for j in key_cols:
            key = key + data[j]
    # for j in range(len(data)):
    #     # get the key
    #     if j in key_cols:
    #         key = key + data[j]
    return key


def get_dict_values(data, value_cols=None):
    values = []
    if not value_cols:
        values = data
    else:
        for j in value_cols:
            values.append(data[j])
        # for j in range(len(data)):
        #     if j in value_cols:
        #         values.append(data[j])
    return values


def read_data_to_dict(data, key_cols=None, value_cols=None):
    """

    :param data: list
    :param key_cols: list
    :param value_cols: list
    :return:list_dict
    """
    list_dict = {}
    for row in data:
        # get the key
        key = get_dict_key(row, key_cols)
        # get the values
        values = get_dict_values(row, value_cols)
        # append to dict
        list_dict.setdefault(key, []).extend(values)
    return list_dict


def get_sub_data(data, sub_cols=None):
    """
    get sub data from data as per sub_cols
    :param data:
    :param sub_cols:
    :return:
    """
    sub_data = []
    if not sub_cols:
        sub_data = data
    else:
        for row in data:
            new_row = []
            for col in sub_cols:
                if col < len(row):
                    new_row.append(row[col])
                else:
                    new_row.append("")
            sub_data.append(new_row)
    return sub_data


def new_data_header(data, Headers):
    new_data = []
    if data:
        for row in range(len(data)):
            if not row:
                new_data.append(Headers)
            else:
                new_data.append(data[row])
    return new_data


def compare(data1, data2, indexs_data1, indexs_data2):
    look_in1 = []
    look_in2 = []
    look_out1 = []
    look_out2 = []
    data1_dict = read_data_to_dict(data1, indexs_data1)
    data2_dict = read_data_to_dict(data2, indexs_data2)
    for row in data1:
        key = get_dict_key(row, indexs_data1)
        if key in data2_dict:
            look_in1.append(row)
        else:
            look_out1.append(row)
    for row in data2:
        key = get_dict_key(row, indexs_data2)
        if key in data1_dict:
            look_in2.append(row)
        else:
            look_out2.append(row)
    return look_out1, look_out2, look_in1, look_in2


def vlookup(src_data, look_data, indexs_look_src=None, indexs_look_in=None, indexs_look_out=None):
    """

    :param src_data:list
    :param look_data:list
    :param indexs_look_src:list
    :param indexs_look_in:list
    :param indexs_look_out:list
    :return:
    """
    look_dict = read_data_to_dict(look_data, indexs_look_in, indexs_look_out)
    merge_data = []
    for row in src_data:
        # get the key
        key = get_dict_key(row, indexs_look_src)
        data1 = get_dict_values(row)         # get the data1
        # extend the data1
        if key not in look_dict:
            # append "" if the key not in dict
            for i in indexs_look_out:
                data1.append("")
        else:
            # extend the value of dict
            data1.extend(get_dict_values(look_dict[key]))
        # data1 append to merge_data
        merge_data.append(data1)
    return merge_data


if __name__ == "__main__":
    pass
