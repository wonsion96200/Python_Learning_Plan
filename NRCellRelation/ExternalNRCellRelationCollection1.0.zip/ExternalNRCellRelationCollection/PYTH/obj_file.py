#!python2
# coding=utf-8
import datetime
import glob
import os
import re
import shutil

"""
common function for file and dirs 
"""


def copy_file_list(list_path="", copy_to_path=""):
    """
    copy the file list to report_path
    :param copy_to_path:
    :param list_path:
    :return:
    """
    mkdir(copy_to_path)
    lines = get_file_list(list_path)
    for line in lines:
        copy_file(line, copy_to_path)


def cleanup_path(path_name):
    if os.path.exists(path_name):
        shutil.rmtree(path_name)
    os.makedirs(path_name)
    print ("cleanup %s" % path_name)


def rm_file(file_name=None):
    if os.path.isfile(file_name):
        shutil.rmtree(file_name)
        print ("rm %s" % file_name)


def rm_dirs(dir_name=None):
    if os.path.isdir(dir_name):
        shutil.rmtree(dir_name)
        print ("rm -r %s" % dir_name)


def mkdir(dir_name=""):
    if not os.path.isdir(dir_name):
        os.system("mkdir %s" % dir_name)
        print ("mkdir %s" % dir_name)


def copy_file(file_src="", dir_dst=""):
    mkdir(dir_dst)
    if os.path.isfile(file_src):
        os.system("cp -f %s %s" % (file_src, dir_dst))
        print "cp -f %s %s" % (file_src, dir_dst)


def file_time_more_than_1day(file_name=None):
    """
    check the file time
    :return True if file not be found or time more than 24 hours
    :return False if file time is less than 24 hours
    :type file_name: str
    """
    if not os.path.isfile(file_name):
        flag = True
    else:
        now = datetime.datetime.now()
        # noinspection PyPep8Naming
        delta_24hour = datetime.timedelta(seconds=86400)
        f = datetime.datetime.fromtimestamp(os.path.getmtime(file_name))
        if f < (now - delta_24hour):
            flag = True
        else:
            flag = False
    return flag


def time_less_than_30days(valid_time=None):
    """
    check the file time
    :param valid_time:
    :return True if time less than 30 days
    :return False if time is more than 30 days
    """
    flag = False
    if valid_time:
        now = datetime.datetime.now()
        delta_30days = datetime.timedelta(days=30)
        f = datetime.datetime.strptime(valid_time, '%Y-%m-%d')
        if f < (now + delta_30days):
            flag = True
        else:
            flag = False

    return flag


def get_file_list(file_path=""):
    file_list = []
    if os.path.isfile(file_path):
        file_list = [x.strip() for x in open(file_path, 'r').readlines()]
    return file_list


def write_lists_to_file(file_path="", lines=None):
    if lines is None:
        lines = []
    with open(file_path, 'w') as f:
        for line in lines:
            f.write(line.rstrip()+'\n')
    return file_path


def get_filePath_fileName_fileExt(fileUrl):
    """
    get file path, file name and file extension
    :param fileUrl:
     :return:
     """
    filepath, tmp_filename = os.path.split(fileUrl)
    shot_name, extension = os.path.splitext(tmp_filename)
    return filepath, shot_name, extension


def text_re_searched(data=None, line=""):
    flag = False
    if data:
        for i in data:
            regex1 = re.compile(i)
            if regex1.search(line):
                flag = True
                break
    return flag


def file_number(fileUrl):
    """
    get file number
    :param fileUrl:
     :return: number of exist files
     """
    path_file_number = glob.glob(fileUrl)
    return path_file_number


def file_sort(input_file="", sort_file="", output_file=""):
    new_file = dst_list = []
    if not output_file:
        output_file = input_file
    if os.path.exists(input_file) and os.path.exists(sort_file):
        if os.path.getsize(input_file):
            src_list = open(input_file).readlines()
            new_file = [open(input_file).readline()]
            sort_list = open(sort_file).readlines()
            for sort in sort_list:
                for src in src_list:
                    if (sort.strip() + ",") in src:
                        dst_list.append(src)
            if dst_list:
                new_file.extend(dst_list)
    if new_file:
        with open(output_file, "w") as f:
            f.writelines(new_file)
            if input_file == output_file:
                print "resort file %s with %s" % (output_file, sort_file)
            else:
                print "resort file %s with %s to %s" % (output_file, sort_file, output_file)
    return output_file


if __name__ == '__main__':
    in_file = "/home/ejungwa/hcTool/report/invxc_Board.csv"
    sort_f = "/home/ejungwa/hcTool/config/sitelist.txt"
    ou_file = "/home/ejungwa/hcTool/report/new_invxc_Board.csv"

    file_sort(in_file, sort_f, ou_file)
