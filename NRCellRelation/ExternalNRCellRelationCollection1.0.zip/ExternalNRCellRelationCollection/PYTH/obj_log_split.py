#!python2
# coding=utf-8
import os
import re


def log_split(log_path=None):
    # get all log files
    # split_path = log_path + "/log_split"
    split_path = log_path
    for root_dir, dirs, files in os.walk(log_path):
        for file_name in files:
            # get the log file name
            # site_name = file.split(".")[0]
            site_name = file_name[:-4]
            # create split_path
            if not os.path.isdir(split_path):
                os.makedirs(split_path)
            with open("%s/%s" % (root_dir, file_name), "r") as f:
                # read log file
                log_file = f.read()
                # split the log file as per "\w+> |\d+.\d+.\d+.\d+> "
                log_lists = re.split(r"\w+> |\d+.\d+.\d+.\d+> ", log_file)
                i = 0
                for command_info in log_lists:
                    # get the command
                    command = re.split("\n", command_info)[0].lower()
                    # skip the 0
                    if i > 0:
                        # replace (" " or . or | or -) to nothing
                        command = "".join(re.split(r"\s|\.|\||-|'|=|\$|\^|_|\(|\)|\/", command))
                        # write to new log file
                        with open("%s/%s_%s.log" % (split_path, site_name, command), "w") as new_log_file:
                            new_log_file.write(command_info)
                    i = i + 1
    # return the log file split path
    return split_path


if __name__ == '__main__':
    log_split("/home/ejungwa/hcTool/log/15-45")
