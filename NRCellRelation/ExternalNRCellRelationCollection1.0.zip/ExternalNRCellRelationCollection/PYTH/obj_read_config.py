#!python2
# coding=utf-8
import datetime
import os
import sys


class Config(object):
    def __init__(self):
        self.tool_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.config_path = os.path.join(self.tool_path, "config")
        self.site_info = os.path.join(self.config_path, "all_sitelist.txt")

        with open(r"%s/config/config.json" % self.tool_path, "r") as f:
            self.config = eval(f.read())
            self.moshell_path = self.config.get("moshell_path")

        self.mos_commands = os.path.join(self.tool_path, "MOS/hc.mos")
        self.output_path = os.path.join(self.tool_path, "output")
        self.report_path = os.path.join(self.tool_path, "report")
        self.src_file_list = "file_list_src.txt"
        self.dst_file_list = "file_list_dst.txt"

        self.date_time = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        self.date = datetime.datetime.now().strftime("%Y-%m-%d")
        self.log_path = os.path.join(self.tool_path, "log/" + self.date_time)

        if not os.path.exists(self.log_path):
            os.makedirs(self.log_path)
        if not os.path.exists(self.output_path):
            os.makedirs(self.output_path)
        if not os.path.exists(self.report_path):
            os.makedirs(self.report_path)

        if len(sys.argv) == 1:
            self.log_prefix = ""
        else:
            self.log_prefix = sys.argv[1]
            if self.log_prefix.endswith("_"):
                pass
            else:
                self.log_prefix = self.log_prefix + "_"


if __name__ == '__main__':
    pass
    # conf = Config()
